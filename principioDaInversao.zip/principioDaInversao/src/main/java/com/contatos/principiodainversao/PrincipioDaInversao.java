/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.contatos.principiodainversao;

/**
 *
 * @author tgp
 */
public class PrincipioDaInversao {
    public static void main(String[] args){
          Lampada lamp = new Lampada();
          Interruptor inter = new Interruptor(lamp);
          inter.Apertar();
          inter.Apertar();
    }
}
