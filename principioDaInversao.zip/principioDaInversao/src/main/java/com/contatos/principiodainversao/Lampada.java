/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.contatos.principiodainversao;

/**
 *
 * @author tgp
 */
public class Lampada implements Dispositivo {
    
    private boolean ligado;

    public Lampada() {
        this.ligado = false;
    }

    
    
    
    @Override
    public void ligar() {
        System.out.println("Lampada ligada!");
    }

    @Override
    public void desligar() {
        System.out.println("Lampada desligada!");
    }

    @Override
    public void acionar() {
        if(this.ligado != true){
            this.ligar();
            this.ligado = true;
        }else{
            this.desligar();
        }
    }
}
